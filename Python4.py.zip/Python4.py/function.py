# One Stop Insurance Company
# Date Written: November 28, 2023
# Author: Ifunanya Ejeckam

# Import Required Libraries
import datetime
import FormatValues as FV

# Set up Program Constants
POLICY_NUM = 1944
BASIC_PREM = 869.00
ADD_CAR_DISC = 0.25
EXTRA_LIA_COV_COST = 130.00
GLASS_COV_COST = 86.00
LOANER_CAR_COV_COST = 58.00
HST_RATE = 0.15
PROCESS_FEE = 39.99

# Set up Program Functions
def MonthlyPayCal (TotalCost, PaymentMethod):
 # Monthly Payment over 8 months
    if PaymentMethod == "Monthly":
        MonthlyPay = (PROCESS_FEE + TotalCost)/8
    elif PaymentMethod == "DownPayment":
        MonthlyPay = ((TotalCost - DownPayment) + PROCESS_FEE) / 8
    elif PaymentMethod == "Full":
        MonthlyPay = 0
    return MonthlyPay
    
def FirstPayDateCal(InvoiceDate):
    global FirstPayDate
# First Payment Date Calculations
    InvoiceDate = datetime.datetime.now()

# Define the current date
    InvoiceYear = InvoiceDate.year
    InvoiceMonth = InvoiceDate.month + 1
    InvoiceDay = 1

    if InvoiceMonth > 12:
        InvoiceMonth -= 12
        InvoiceYear  += 1

        FirstPayDate = datetime.datetime(InvoiceYear, InvoiceMonth, InvoiceDay)
    return FirstPayDate

    # Start the Main Program

while True:
    FirstName = input ("Enter Customer First Name: "). title()
    LastName = input ("Enter Customer Last Name: "). title()
    Address = input ("Enter Customer Address: ")
    City = input ("Enter Customer City: "). title()
    Provinces = ["NL", "NS", "NB"]
    while True:
        Province = input ("Enter Customer Province: (XX) "). upper()
        if Province =="":
            print("Error message - Province cannot be blank. Please re-enter: ")
        elif len (Province)!=2:
            print("Error - Province is a 2 digit code. Please re-enter: ")
        elif Province not in Provinces:
            print("Error - Province not valid. Please re-enter: ")
        else:
            break
    PostalCode = input ("Enter Customer Postal Code:(X9X 9X9): ")
    PhoneNum = input ("Enter Customer Phone Number(9999999999): ")
    NumCarsInsured = int(input ("Enter Number of Cars Insured: "))
    ExtraLiability = input ("Enter Extra Liability up to $1,000,000 (Y/N): ").upper()
    GlassCoverage = input ("Enter Glass Coverage (Y/N): ").upper()
    LoanerCar = input ("Enter Loaner Car (Y/N) ").upper()
    PaymentOptions = ["Full", "Monthly", "DownPayment"]
    while True:
        PaymentMethod = input ("Enter Payment Method (Full/Monthly/DownPayment): "). title()
        if PaymentMethod =="":
            print ("Error - PaymentMethod cannot be blank. Please re-enter: ")
        elif PaymentMethod not in PaymentOptions:
            print("Error - PaymentMethod must be Full/Monthly/DownPayment. Please re-enter: ")
        else:
            break
        if PaymentMethod =="DownPayment":
         DownPayment = float(input ("Enter Down Payment: "))
        elif PaymentMethod == "Full":
            DownPayment = 0

    ClaimNumList = []
    ClaimDateList = []
    ClaimCostList = []
    
    while True:
        ClaimNum= input ("Enter the Claim Number (Enter to End): ")
        if ClaimNum == "":
            break
        ClaimDate = input("Enter the Claim Date YYYY-MM-DD: ")
        ClaimDate = datetime.datetime.strptime (ClaimDate, "%Y-%m-%d")
        ClaimCost = float(input("Enter the Total Claim Cost: "))
    
        ClaimNumList.append(ClaimNum)
        print (ClaimNumList)
        ClaimDateList.append(ClaimDate)
        print (ClaimDateList)
        ClaimCostList.append(ClaimCost)
        print (ClaimCostList)
  
    # Calculations
    AutoPayment = BASIC_PREM
    if NumCarsInsured > 1:
        AutoPayment = BASIC_PREM + (NumCarsInsured * (BASIC_PREM * ADD_CAR_DISC))
        TotalExtraCost = EXTRA_LIA_COV_COST + GLASS_COV_COST + LOANER_CAR_COV_COST
        TotalInsurancePremium = AutoPayment + TotalExtraCost
        Hst = TotalInsurancePremium * HST_RATE
        TotalCost = TotalInsurancePremium + Hst
        MonthlyPay = MonthlyPayCal (TotalCost, PaymentMethod)

    # Current Date
    InvoiceDate = datetime.datetime.now()
    FirstPayDate = FirstPayDateCal(InvoiceDate)

    #Display Results

    print()
    print(f"                    ONE STOP INSURANCE COMPANY")
    print(f"                  INSURANCE POLICY CLAIM RECEIPT")
    print()
    print(f"Invoice Date: {FV.FDateS(InvoiceDate):<10} Next Policy Number: {POLICY_NUM:>-4}")
    print (f"==================================================================================================")
    print()
    print(f"{FirstName:<10s} {LastName:<10s}")
    print()
    print(f"{Address:<18s},")
    print()
    print(f"{City:<9s},  {Province:<2s}, {PostalCode:<7s}")
    print()
    print(f"{PhoneNum:<10}")
    print()
    print(f"Number of Cars Insured: {NumCarsInsured:>2d}")
    print()
    print(f"Extra Liability: {ExtraLiability:<3s} Glass Coverage: {GlassCoverage:<3s} Car Loan: {LoanerCar:<3s}")
    print()
    print(f"Total Basic premium: {FV.FDollar2(AutoPayment):>9s}")
    print()
    print(f"Total Extra Cost: {FV.FDollar2(TotalExtraCost):>9s}")
    print()
    print(f"Total Insurance premium:)   {FV.FDollar2(TotalInsurancePremium):>9s}")
    print()
    print(f"HST: {FV.FDollar2(Hst):>9s}")
    print()
    print(f"Total Cost: {FV.FDollar2(TotalCost):>9s}")
    print()
    print(f"==================================================================================================")
    print(f"Payment Method: {PaymentMethod:<12s}")
    print(f"Monthly Payment: {FV.FDollar2(MonthlyPay):<12s}")
    print()
    print(f"First Pay Date: {FV.FDateS(FirstPayDate):<10}")
    print()
    print(f"Claim #         Claim Date              Amount ")
    print(f"------------------------------------------------")
    Index = 0
    for Claim in ClaimNumList:
        print(f" {str(ClaimNumList[Index])}         {str(ClaimDateList[Index])}     {FV.FDollar2(ClaimCostList[Index]):<9s}")
        Index +=1

    print()
    print()
    while True:
        cont = input("Do you want to continue another claim (Y/N): ").upper() 
        if cont=="N":
            break
    print()
    print ("Thank you and have a nice day")
    
